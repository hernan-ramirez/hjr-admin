================================================================================
README.TXT - Getting Started Information
--------------------------------------------------------------------------------
WebTabs 1.0 Trial Edition
Version 1.0.0
(C) 2004 Phyrix Systems (Pty) Ltd
http://www.phyrix.com
================================================================================


Files Included Software Distribution
------------------------------------

The following files are included in this .ZIP archive.

licence.txt               : Licence agreement
webtabs.js                : WebTabs JavaScript source (compressed)
webtabs.css               : WebTabs CSS theme
userguide.html            : WebTabs user guide
WebTabs_demo_1.html       : WebTabs demo #1
WebTabs_demo_2.html       : WebTabs demo #2
WebTabs_demo_3.html       : WebTabs demo #3
readme.txt                : Getting started information (this file)
about.gif                 : Image for demos and user guide
contact.gif               : Image for demos and user guide
forum.gif                 : Image for demos and user guide
home.gif                  : Image for demos and user guide
news.gif                  : Image for demos and user guide
webtabs.gif               : Image for user guide


Using WebTabs
-------------

To get started with WebTabs, read the user guide; open the file "userguide.html"
in your web browser.


================================================================================
